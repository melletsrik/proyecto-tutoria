<script setup>
import '@/assets/estilos/Footer.css';
</script>

<template>
  <footer class="footer">
    <div class="footer-button">
      <i class="material-icons">settings</i>
      <p>Configuración</p>
    </div>
    <div class="footer-button">
      <i class="material-icons">home</i>
      <p>Inicio</p>
    </div>
    <div class="footer-button">
      <i class="material-icons">notifications</i>
      <p>Notificaciones</p>
    </div>
  </footer>
</template>
